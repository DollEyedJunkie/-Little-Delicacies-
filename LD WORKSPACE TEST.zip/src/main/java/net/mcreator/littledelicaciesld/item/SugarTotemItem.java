
package net.mcreator.littledelicaciesld.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.mcreator.littledelicaciesld.itemgroup.LDItemsItemGroup;
import net.mcreator.littledelicaciesld.LittleDelicaciesModElements;

@LittleDelicaciesModElements.ModElement.Tag
public class SugarTotemItem extends LittleDelicaciesModElements.ModElement {
	@ObjectHolder("little_delicacies:sugar_totem")
	public static final Item block = null;
	public SugarTotemItem(LittleDelicaciesModElements instance) {
		super(instance, 85);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(LDItemsItemGroup.tab).maxStackSize(64).isImmuneToFire().rarity(Rarity.RARE));
			setRegistryName("sugar_totem");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 0F;
		}
	}
}
