
package net.mcreator.littledelicaciesld.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.littledelicaciesld.item.StrawberryMilkshakeItem;
import net.mcreator.littledelicaciesld.LittleDelicaciesModElements;

@LittleDelicaciesModElements.ModElement.Tag
public class LDItemsItemGroup extends LittleDelicaciesModElements.ModElement {
	public LDItemsItemGroup(LittleDelicaciesModElements instance) {
		super(instance, 147);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabld_items") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(StrawberryMilkshakeItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
