
package net.mcreator.littledelicaciesld.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.littledelicaciesld.item.CurryItem;
import net.mcreator.littledelicaciesld.LittleDelicaciesModElements;

@LittleDelicaciesModElements.ModElement.Tag
public class CafeFoodsItemGroup extends LittleDelicaciesModElements.ModElement {
	public CafeFoodsItemGroup(LittleDelicaciesModElements instance) {
		super(instance, 87);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabld_cafe_food") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(CurryItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
